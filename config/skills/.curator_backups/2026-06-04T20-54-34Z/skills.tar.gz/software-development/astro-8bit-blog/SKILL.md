---
name: astro-8bit-blog
category: software-development
description: Initialize and build an Astro static blog with an 8-bit NES design system — native CSS tokens, semantic HTML, Playwright smoke tests, and Lighthouse-optimized dark-mode layout.
---

# Astro 8-Bit Blog

This skill governs the full lifecycle of the Astro blog at `/Users/eric/repos/blog`: scaffolding, design tokens, layout, content, testing, and performance optimization.

> **🚫 DEPRECATED REPO:** The `my-blog` repo at `/Users/eric/repos/my-blog` is DEPRECATED. Do NOT start, continue, or migrate work there. If you discover changes in `my-blog`, reapply them to `/Users/eric/repos/blog` instead. Always `cd /Users/eric/repos/blog` before starting work.

## 🎨 Design System: Clean 8-Bit NES Vibe

The visual language is a modern, readable interpretation of retro NES aesthetics — chunky 2px pixel borders, monospace typography, high-contrast dark mode. No scanline filters, no vibrating backgrounds.

### Core Tokens (defined in `src/styles/global.css` as CSS custom properties)

The project uses **native CSS custom properties** in `:root` for all design tokens. Color values are pre-computed hex literals (no SCSS color functions). Components consume tokens via `var(--*)` references.

**CSS custom properties** (in `src/styles/global.css`, consumed by component `<style>` blocks):

**Font tokens** (static, in `:root`):
| CSS Custom Property | Value | Purpose |
|---------------------|-------|---------|
| `--font-family-display` | `'Syncopate', sans-serif` | Syncopate — all-caps display headers, nav, UI |
| `--font-family-body` | `'Inter', sans-serif` | Inter — reading prose, body text |
| `--font-family-mono` | `'Fira Code', monospace` | Fira Code — code blocks, technical content |

**Theme-aware color tokens** (in `:root, html[data-theme="dark"]` and `html[data-theme="light"]`):
| CSS Custom Property | Dark Value | Light Value | Purpose |
|---------------------|------------|-------------|---------|
| `--color-sys-bg` | `#0f0f14` | `#f4f4f5` | Page background |
| `--color-sys-text` | `#f3f4f6` | `#09090b` | Primary text |
| `--color-card-bg` | `#16161e` | `#ffffff` | Card/surface background |
| `--color-border` | `#2e2e3f` | `#e4e4e7` | Borders |
| `--color-brand-danger` | `#ef4444` | `#dc2626` | Konami Red — alerts, active states |
| `--color-led-glow` | `#22c55e` | `#ef4444` | Status LED (green→red in light mode) |

**Static color tokens** (in `:root`, theme-independent):
| CSS Custom Property | Value | Purpose |
|---------------------|-------|---------|
| `--color-brand-primary` | `#a1a1aa` | Nav links, secondary text |
| `--color-brand-accent` | `#3b82f6` | Capcom Blue — hover, highlights |
| `--color-brand-gold` | `#eab308` | Gold accents |
| `--size-border-pixel` | `2px` | Chunky pixel-stepped borders |

**Legacy tokens** (still in `:root` for backward compat, prefer semantic aliases above):
| CSS Custom Property | Value | Purpose |
|---------------------|-------|---------|
| `--color-bg` | `#09090b` | Deep arcade CRT background (legacy) |
| `--color-surface` | `#1a1a24` | Elevated surface (legacy) |
| `--color-surface-raised` | `#2a2a36` | Highest lift (legacy) |
| `--color-text` | `#e4e4e7` | High-contrast reading text (legacy) |
| `--color-sys-surface` | `var(--color-surface)` | Semantic alias for component use |
| `--font-atkinson` | `var(--font-family-body)` | Legacy bridge alias — do NOT use for new work |

> **⚠️ Token naming note:** Always use the `--color-sys-*` semantic aliases in component `<style>` blocks for theme-aware colors. Use `--color-brand-*` for static brand colors. Legacy `--color-*` tokens are kept for backward compat but should not be used in new work.

Full variable reference: `references/design-tokens.md` (updated to match current SCSS vars + CSS custom properties)
Build error catalog: `references/build-error-catalog.md`
Astro `<Image />` component API: `references/astro-image-component.md`
SEO & social metadata pattern: `references/seo-social-metadata.md`
Content schema patterns (incl. `auditAssert`): `references/content-schema-patterns.md`
Lighthouse CI component patterns (GlobalScoreboard, PostAuditBanner): `references/lighthouse-ci-components.md`
SEOHead missing global.scss diagnostic: `references/seohead-global-scss-fix.md`
Git commit hygiene (recovering from bad commits, `.gitignore` template): `references/git-commit-hygiene.md`
JSON-LD SchemaGraph component (type-safe `@graph` engine, conditional BlogPosting): `references/json-ld-schema-graph.md`
Astro 6 content entry identity (`post.id` vs `post.slug`): `references/astro6-content-entry-identity.md`
Light/dark theme switching (zero-flash, semantic tokens, CSS-state-driven ThemeToggle): `references/theme-switching.md`
Playwright config template: `templates/playwright.config.js`
Smoke test template: `templates/smoke.spec.js`

## ⚡ Tech Stack

- **Framework:** Astro (latest stable) with strict TypeScript
- **Styling:** Native CSS (no preprocessor). Global tokens in `src/styles/global.css` using `:root` + OKLCH color space. Component styles use scoped `<style>` tags (no `lang` attribute — plain CSS with native `&` nesting).
- **Content:** `.mdx` files in `src/content/blog/`
- **Testing:** Playwright (`@playwright/test`) — smoke tests in `tests/`
- **Node:** Requires ≥22.12.0 (activate via `nvm use 24` — the default alias on this machine)

## 🏗️ Layout Structure

Pages in both repos use a `BaseLayout` component at `src/layouts/BaseLayout.astro`:

```astro
---
import BaseLayout from '../layouts/BaseLayout.astro';
import RetroText from '../components/atoms/RetroText.astro';
---
<BaseLayout>
  <main class="arcade-container">
    <!-- page content -->
  </main>
</BaseLayout>
```

`BaseLayout` is responsible for `<html>`, `<head>` (meta, token stylesheet link, font preconnect), `<body>`, `<header>/<nav>`, and `<footer>`. Pages only supply `<main>` content.

> **⚠️ Native CSS (no SCSS):** This project uses native CSS (`src/styles/global.css`) — no preprocessor. Design tokens are CSS custom properties in `:root` inside `global.css`. Component `<style>` blocks use plain CSS with native `&` nesting (no `lang="scss"` attribute). Import patterns reference `.css` files, not `.scss`.

## 🏗️ Project Setup Sequence

1. `npm create astro@latest my-blog -- --template minimal --no-install --no-git --typescript strict`
2. `npm install && npm install --save-dev @playwright/test sass`
3. `npx playwright install chromium`
4. Create `src/styles/global.scss` with OKLCH color tokens inside `:root { ... }` (see token table above)
5. Import `global.scss` in the base layout or page frontmatter using the project's existing SCSS import pattern
6. Build semantic HTML structure: `<header>`, `<nav>`, `<main>`, `<section>`, `<footer>` with ARIA labels
7. Create `playwright.config.js` with dev server config (port 4321)
8. Create `tests/smoke.spec.js` — compile check, semantic landmarks, accessibility

### ⚠️ Pitfalls — Setup

- **Node version:** Astro ≥5.x requires Node ≥22. Activate with `export NVM_DIR="$HOME/.nvm" && source "$NVM_DIR/nvm.sh" && nvm use 22` before any npm/node command in terminal.
- **`NODE_ENV=production` skips devDependencies:** On macOS, `NODE_ENV` may be set to `production` globally, causing `npm install` to skip all `devDependencies`. Always use `NODE_ENV=development npm install`. Verify with `echo $NODE_ENV`.
- **CSS token import:** In Astro layouts, tokens are available globally via `global.css` which is imported by the layout or page. For page-level scoped styles, use `<style>` (plain CSS, no `lang` attribute). Do NOT reference `tokens.css` or `global.scss` — those files do not exist.
- **Playwright webServer:** Use `npm run dev` (not `preview`) for test server, with `reuseExistingServer: !process.env.CI`.
- **Playwright as devDependency:** Install with `npm install --save-dev @playwright/test` — NOT as a production dependency. If it lands in `dependencies`, run `npm uninstall @playwright/test && npm install --save-dev @playwright/test`.
- **Stale dev server on port 4321:** If Playwright's `webServer` times out, a leftover process may be holding port 4321. Kill it: `lsof -ti:4321 | xargs kill -9`, then retry.
- **Vite HMR stale cache serving old styles:** When scoped `<style>` in `.astro` files is correct on disk but the browser renders old/different styles (e.g., `background: white` instead of dark token), the cause is almost always Vite HMR cache from the running dev server. **Killing the dev server is the diagnostic step** — after restart, the correct styles appear. Do not chase CSS specificity when the file on disk is already correct; kill the server first.
- **Git commit hygiene — `.gitignore` must exist before committing:** If a repo has no `.gitignore` (or an empty one), `git add .` or even targeted `git add` can pull in tracked-but-modified files from `node_modules/`, `dist/`, `.astro/`. Always write a proper `.gitignore` first, verify with `git status --short`, then use explicit `git add <file>` paths (never `git add .`). If a bad commit was made, `git reset HEAD~1` returns to the pre-commit state. **Never run `git rm -r --cached node_modules/`** — it times out on large directories; just stage the specific files you want to commit instead.
- **Sibling repo files:** When a file (e.g., `content.config.ts`) is not found in the current project, a sibling repo may contain it. Check `../<repo>/src/` before concluding the file doesn't exist. Use `ls ../` to list sibling directories when the user provides a path hint like `../blog/src/...`.

### ⚠️ Pitfalls — Lighthouse CI

- **Install:** `NODE_ENV=development npm install --save-dev @unlighthouse/cli @lhci/cli@0.15.x` — pinned to 0.15 line for compatibility.
- **Config file:** `lighthouserc.js` at repo root with `startServerCommand: 'npm run preview'`, `url: ['http://localhost:4321/']`, `numberOfRuns: 3`. Strict gates: perf ≥0.95, a11y ≥0.95, SEO ≥1.0, best-practices ≥0.95.
- **package.json scripts:** `"audit": "astro build && npx unlighthouse --site http://localhost:4321"` and `"assert-ci": "astro build && npx lhci autorun"`.
- **Port 4321:** Matches Astro default preview port. If already in use, `lsof -ti:4321 | xargs kill -9`.

### ⚠️ Pitfalls — Reading Files at Build Time in Astro Frontmatter

- **`process.cwd()` is flagged by ESLint** as undefined in Astro frontmatter. Use `import { fileURLToPath } from 'node:url'` with `new URL('../../relative/path', import.meta.url)` to resolve filesystem paths reliably.
- **Pattern for reading JSON at build time:**
  ```astro
  ---
  import { readFileSync } from 'node:fs';
  import { fileURLToPath } from 'node:url';
  import { resolve, dirname } from 'node:path';
  const ciResultPath = fileURLToPath(new URL('../.unlighthouse/ci-result.json', import.meta.url));
  // readFileSync(ciResultPath, 'utf-8') ...
  ---
  ```
- **Graceful fallback:** When the file doesn't exist (audit not yet run), catch the error and render fallback/default values. Never let a missing CI result file crash the build.

### ⚠️ Pitfalls — Content Schema Mutation

- **Adding required fields:** Every `.md`/`.mdx` in `src/content/blog/` must be updated. Missing any file causes a build error on that post.
- **Adding optional fields with `.default()`:** Existing posts are safe — Zod fills the default at build time. Astro's content store auto-invalidates and resyncs on schema change (expected, not an error).
- **Schema sub-objects (e.g., `auditAssert`):** Group related fields into a `z.object()` with `.default()` for graceful fallback. Use `.min()` for score floors, not `.max()`.
- **After schema changes:** Always run `npm run lint && npm run build` to verify. Content store resync is visible in build output — 5 posts should load.

### ⚠️ Pitfalls — SCSS → Native CSS Migration

- **SCSS has been retired.** `src/styles/global.scss` was replaced by `src/styles/global.css` with all SCSS-specific syntax removed: `$variables` → literal hex values, `#{}` interpolation → literals, `//` comments → `/* */`. `sass` was uninstalled.
- **Migration procedure (for future reference / catching regressions):**
  1. Write `global.css` converting all SCSS syntax: `$variables` → literal values, `rgba($var, alpha)` → literal rgba, `//` comments → `/* */`. Native `&` nesting is preserved (supported in all modern browsers).
  2. Update **ALL** imports: `global.scss` → `global.css` in every component that imports it (head components, layouts).
  3. Change `<style lang="scss">` → `<style>` (plain CSS) in ALL components.
  4. Run `npx biome check --write .` for bulk auto-fix (safe mode only — do NOT use `--unsafe`).
  5. Fix remaining Biome warnings manually — unused variables in Astro frontmatter props should be **underscore-prefixed** (`_pubDate`, `_tags`, `_date`, `_props`, `_Content`, etc.) to suppress false positives without changing runtime behavior. **Do NOT run `--unsafe`** — it will add `_` prefixes to variables that ARE used in the template, re-introducing ReferenceErrors.
  6. Remove `!important` from utility classes (`.sr-only`, `.no-js-emulation`) — they have sufficient specificity.
  7. Run `rm src/styles/global.scss` (destructive — verify imports are rewired first).
  8. Run `npm uninstall sass`.
  9. Run `NODE_ENV=development npm install` to sync.
  10. Run `npm run build` — verify clean build.
  11. Run `npm run build && npx playwright test` — verify no regressions.
- **`npx biome check --write .`** auto-fixes safe issues (semicolons, quote style, unused imports) but leaves 15-20 warnings for manual fix (unused vars, `!important`, etc.). The manual fixes are predictable: underscore-prefix unused Astro props, remove unnecessary `!important`. **Do NOT follow up with `--unsafe`** — it will revert your manual fixes by adding `_` prefixes to variables used in templates.

### ⚠️ Pitfalls — Underscore-Prefixed Variable Mismatch in `.astro` Frontmatter

- **The bug pattern:** Destructuring with rename aliases like `const { tag: _Tag, title: _title } = Astro.props` or `const _scores = ...` — then referencing the *non-underscore* name (`Tag`, `title`, `scores`) in the template. The underscore prefix silences linters but creates a runtime `ReferenceError` because the bare name was never declared.
- **Why it's systemic:** A Biome/lint autofix pass or manual "suppress unused variable" edit can rename declarations to `_var` without updating all template references. Every `.astro` file is susceptible.
- **Diagnostic signal:** Build succeeds but runtime rendering fails with `ReferenceError: <Name> is not defined` pointing to a prerender chunk. The stack trace references the component factory — trace it back to the `.astro` file.
- **Fix pattern:** Remove the underscore prefix from the declaration (`const { tag: Tag }` or `const scores = ...`). Do NOT add the underscore to the template references.
- **Prevention:** After any lint autofix pass, search for the pattern: `grep -rn "const _\w\+\s*=" src/ --include="*.astro"` and verify each `_`-prefixed variable is actually used with the `_` prefix in the template. If the template uses the bare name, the declaration must match.
- **Files affected in this session (all fixed):** `RetroText.astro`, `BlogPost.astro`, `SEOHead.astro`, `PostAuditBanner.astro`, `GlobalScoreboard.astro`, `HeaderLink.astro`, `Footer.astro`, `FormattedDate.astro`, `blog/index.astro`, `[...id].astro`

### ⚠️ Pitfalls — Biome Format/Check with Astro Components

- **Biome cannot analyze Astro template variable usage.** Biome's static analysis only sees the frontmatter `<script>` block — it cannot detect that variables are used in the HTML template portion of `.astro` files. This produces **false-positive `noUnusedVariables` and `noUnusedImports` warnings** for every component that references frontmatter variables in its template.
- **`npx biome check --write .`** (safe fixes only): Only applies non-destructive fixes (semicolons, quote style, etc.). **Does NOT add `_` prefixes.** Safe to run. Exit code 0 even with warnings.
- **`npx biome check --write --unsafe .`** (unsafe fixes): **DANGEROUS for Astro projects.** This flag tells Biome to auto-fix "unused variables" by prepending `_` to their declarations. Since Biome can't see template usage, it will add `_` prefixes to variables like `canonicalURL`, `Tag`, `scores`, etc. that ARE used in the template — **re-introducing the exact `ReferenceError` bugs you just fixed.**
- **The revert loop:** Running `--unsafe` after manually fixing underscore prefixes will undo your fixes. Running it again will produce the same warnings, creating an infinite loop. **NEVER run `biome check --write --unsafe` on an Astro codebase where components reference frontmatter variables in templates.**
- **The `format` script (`"format": "biome check --write ."`):** This is the safe version without `--unsafe`. Run it freely. Expect ~50 false-positive `noUnusedVariables` warnings — **ignore them.** The build is the source of truth, not Biome's Astro analysis.
- **When you see `noUnusedImports` for components like `BaseLayout`, `Header`, `Footer`, `RetroText`:** These are false positives. Those imports ARE used in the template. Do NOT let Biome remove them. If `--write` removes them (safe fix for imports it can prove are unused), re-add them manually and verify with `npm run build`.
- **Actual lint errors to act on:** `noUnusedVariables` for destructured props that truly have no template reference (e.g., `pubDate` in a layout that never renders it). These can be safely underscore-prefixed or removed. Use judgment — when in doubt, check the template manually.

### ⚠️ Pitfalls — Light/Dark Theme Switching

- **Zero-flash inline script:** A `<script is:inline>` block MUST be placed at the very top of `<head>` (in `BaseHead.astro`), BEFORE any `<style>` or `<link>` tags. It reads `localStorage.getItem('theme-preference')`, defaults to `'dark'`, and sets `document.documentElement.setAttribute('data-theme', theme)`. This runs before the browser paints, preventing FOUC.
- **Semantic CSS variable architecture:** Theme colors are defined as CSS custom properties in `global.css` under two selectors:
  - `:root, html[data-theme="dark"]` — dark mode values (default)
  - `html[data-theme="light"]` — light mode overrides
  - Components consume these via `var(--color-sys-bg)`, `var(--color-sys-text)`, `var(--color-card-bg)`, `var(--color-border)`, etc.
- **Component decoupling — ThemeToggle + HardwareDashboard:** The original `HardwareSwitch.astro` monolith mixed theme state management with hardware emulation simulation in a single component. This has been split into two isolated components:
  - `src/components/ThemeToggle.astro` — **theme only.** Controls `data-theme` on `<html>`, persists to `localStorage` under key `'theme-preference'`, default `'dark'`. Contains slider UI (`#theme-slider-ui`, `#theme-thumb`, `#theme-checkbox-hidden`), click + keydown listeners, `setTheme()` function. **Must NOT contain any emulation/payload logic.**
  - `src/components/molecules/HardwareDashboard.astro` — **emulation only.** Simulates a NES-style zero-JS payload tracking interface with power slider, LED indicator, and status readout. Contains its own slider UI (`#hw-emulation-toggle-ui`, `#hw-switch-thumb`, `#hw-emulation-checkbox`), LED (`#hw-status-led`), mode text (`#hw-status-mode`). **Must NOT contain any theme-state logic or `data-theme` manipulation.**
  - **Scripts must NEVER cross-contaminate.** Each component's `<script is:inline>` block manages its own DOM elements and state only. No shared state, no shared listeners.
  - `ThemeToggle` is integrated globally into `Header.astro` (every page gets it). `HardwareDashboard` is placed on `index.astro` only (homepage simulator).
  - `HardwareSwitch.astro` is **DELETED** — fully superseded by `ThemeToggle.astro` + `HardwareDashboard.astro`. Do NOT recreate it.
- **ThemeToggle localStorage key:** Changed from `'theme-preference'` to `'site-theme'` during SVG icon upgrade. The zero-flash inline script in `BaseHead.astro` still uses `'theme-preference'` — these are now **out of sync**, requiring one refresh cycle for migration. Future work should unify both to the same key (recommend `'site-theme'` for the component, update `BaseHead.astro` to match).
- **All component `<style>` blocks must use semantic tokens** — no hardcoded hex colors that don't respond to theme changes. After adding theme support, audit every component for leftover `#hex` values.

### ⚠️ Pitfalls — Build Errors

- **Stale build cache causes phantom errors:** If build errors reference old files or line numbers that don't match source, clear caches first: `rm -rf dist .astro node_modules/.cache`. Always do a clean rebuild before diagnosing.
- **Missing closing `---` fence in `.astro` frontmatter:** Every `.astro` file's frontmatter must have BOTH an opening `---` and closing `---` fence. A missing closing fence causes `Syntax error in <file>.astro at line N` with only 3 lines of error output. The error points to the first HTML line after the unclosed frontmatter. Fix: add the missing `---` before the HTML/template content.
- **Accidental import removal during patch:** When using `patch` to modify `.astro` frontmatter, a narrow `old_string` can inadvertently remove adjacent import lines. Always include enough context (2-3 lines before and after) in the `old_string` to uniquely identify the target. After patching, verify imports are intact by reading the file back.
- **Native CSS is the styling pipeline:** The project uses `src/styles/global.css` (native CSS) with design tokens as CSS custom properties in `:root`. Do NOT reintroduce SCSS/SASS — the `sass` package has been uninstalled. Component `<style>` blocks must NOT use `lang="scss"` — use plain `<style>` with native CSS nesting (`&`).
- **Sass color functions are banned (legacy):** If migrating old SCSS with `darken()`, `lighten()`, `color.adjust()`, or `color.scale()`, replace all calls with pre-computed hex or OKLCH literals. These functions no longer exist in the dependency tree.
- **Astro `<Image />` component usage:** The native `<Image />` component from `astro:assets` is the correct way to handle images. Import: `import { Image } from 'astro:assets';`. Key rules:
  - **Local images in `src/`**: Import the image file directly (`import myImage from '../assets/photo.png'`) and pass the import as `src={myImage}`. Width/height are auto-inferred.
  - **Images in `public/`**: Use absolute path strings (`src="/photo.jpg"`) but **must** provide explicit `width` and `height` props (Astro cannot analyze `public/` files).
  - **Remote images**: Use the full URL string, provide `width` + `height`, or add `inferSize` to auto-fetch dimensions.
  - **`alt` is always required** — use `alt=""` for decorative images.
  - For responsive images, use `layout="constrained"` (default-like behavior), `layout="full-width"` (hero images), or `layout="fixed"` (icons/logos). Layout auto-generates `srcset` + `sizes`.
  - **Do NOT use plain `<img>` tags** in Astro components — always prefer `<Image />` for optimization (lazy loading, proper `decoding`, WebP output).
  - The `image()` schema helper in `content.config.ts` works with local imports. For `public/` folder images, use `z.string()` and pass the absolute path.
- **Fonts are loaded via Google Fonts `<link>` tags (zero-runtime).** Both `BaseHead.astro` and `SEOHead.astro` must carry the identical preconnect + stylesheet payload for Syncopate 700, Inter 400/500/700, and Fira Code 400/600. No `<Font>` component, no font loader JS. The CSS custom properties wire to these: `--font-family-display` → `'Syncopate'`, `--font-family-body` → `'Inter'`, `--font-family-mono` → `'Fira Code'`.
- **`--font-atkinson` is a legacy bridge alias** pointing to `var(--font-family-body)` (Inter). It exists for backward compatibility only — do NOT use it in new component work. Use `--font-family-body` or `--font-family-mono` instead.
- **Content config location (Astro 6):** The content collection config MUST be at `src/content.config.ts` (root of `src/`), NOT `src/content/config.ts`. Astro 6 throws `LegacyContentConfigError` if it's in the wrong location. The file must define a `glob` loader:
  ```ts
  import { defineCollection } from 'astro:content';
  import { glob } from 'astro/loaders';
  import { z } from 'astro:schema';
  const blog = defineCollection({
    loader: glob({ base: './src/content/blog', pattern: '**/*.{md,mdx}' }),
    schema: z.object({ title: z.string(), ... }),
  });
  export const collections = { blog };
  ```
- **Stale content config files:** When migrating from older Astro versions, BOTH `src/content.config.ts` and `src/content/config.ts` may exist. The old one (often with `(_ctx)` unused parameter) causes ESLint `no-unused-vars` errors and must be deleted. Always `ls src/content*config*` to check.
- **Duplicate `<meta name="title">` is non-standard.** The `<title>` element plus OG `og:title` meta tags are sufficient. Never add `<meta name="title">` — it confuses crawlers and is not part of the HTML spec. If found in any head component, remove it.
- **Dynamic route file naming must match param key.** In Astro 6, `[...slug].astro` with `params: { slug }` and `[...id].astro` with `params: { id }` must stay in sync. After the migration from `post.slug` → `post.id`, the route file was renamed to `[...id].astro` with `params: { id: post.id }`. If you see `[...slug].astro`, it is stale — rename it and update the params object. If the `old_string` spans multiple imported lines, the patch tool may remove more than intended. When editing `.astro` frontmatter where imports and code are tightly coupled, prefer writing the entire frontmatter block via `write_file` on the whole file, or use multiple targeted patches.
- **Scoping `search_files` to project source:** `search_files` matches too broadly by default, returning `node_modules` results. Always add `file_glob` to limit file types (e.g., `*.astro`, `*.{ts,js,astro}`) or use `path` to constrain the directory. Never search the whole project root for source-code patterns.
- **Repo path correction:** The working repo is `/Users/eric/repos/blog`. If you previously worked in `/Users/eric/repos/my-blog` (a minimal single-page site), migrate ALL changes to `blog`. The `blog` repo has the full content collection, layouts, and schema. Always `cd /Users/eric/repos/blog` before starting work.
- **Sibling repo files:** When a file (e.g., `content.config.ts`) is not found in the current project, a sibling repo may contain it. Check `../<repo>/src/` before concluding the file doesn't exist. Use `ls ../` to list sibling directories when the user provides a path hint like `../blog/src/...`.
- **Content schema migration workflow:** When renaming fields (e.g., `heroImage` → `coverImage`) or adding required fields across a content collection: (1) update schema in `content.config.ts`, (2) update layout component to pass new fields, (3) migrate ALL content files (every `.md`/`.mdx` in `content/blog/`), (4) update all page/template references (e.g., listing pages, about page), (5) verify zero stale references remain with `search_files`, (6) run `npm run lint`. Missing any content file causes build errors on that post.
- **Content frontmatter must match schema exactly:** When creating a new `.md`/`.mdx` blog post, every field in the Zod schema must be present in the frontmatter. Do NOT add fields that aren't in the schema (e.g., `tags`, `category`) — they cause `InvalidContentEntryDataError` at build time. Check the schema in `src/content.config.ts` before writing frontmatter. The current required fields are: `title`, `description`, `pubDate`, `coverImage`, `coverAlt`. Optional: `ogTitle`, `ogDescription`, `auditAssert` (has defaults).
- **Content entry `coverImage` path format:** Use public-root paths like `/blog-placeholder-1.jpg`, NOT relative paths like `../../assets/blog-placeholder-1.Bx0Zcyzv.jpg`, and NOT Astro-hashed asset paths. If using a custom image (e.g., a generated NES title graphic), place it in `public/` and reference via public-root path (e.g., `/code-bloat-nes-title.png`). The `src/assets/` directory is for images imported via `import` statements (Astro-optimized); content collection `coverImage` strings are NOT processed by the asset pipeline, so public-root paths are the only option for string-based cover images.
- **Never add `tags` or `category` to blog post frontmatter.** These fields are NOT in the Zod schema and will cause `InvalidContentEntryDataError` at build time. If you want taxonomy, it must be added to the schema in `src/content.config.ts` first AND all existing posts must be updated. The current schema only supports: `title`, `description`, `pubDate`, `coverImage`, `coverAlt`, plus optional `ogTitle`, `ogDescription`, `auditAssert`.
- **New blog post creation checklist:** (1) Read `src/content.config.ts` to confirm the exact schema, (2) Read an existing post to confirm path conventions for `coverImage`, (3) Write the `.md` file with only schema-valid frontmatter fields, (4) Run `npm run build` — the build will catch any missing required fields immediately.

## 🔧 Code Quality: ESLint + Prettier

### ESLint Flat Config (`eslint.config.mjs`)

Install dependencies:
```bash
NODE_ENV=development npm install --save-dev eslint eslint-plugin-astro astro-eslint-parser @typescript-eslint/parser eslint-plugin-jsx-a11y prettier eslint-config-prettier typescript-eslint prettier-plugin-astro ```

The flat config uses the `typescript-eslint` meta-package (not `@typescript-eslint/eslint-plugin` directly):
```js
import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import astroPlugin from 'eslint-plugin-astro';
import astroParser from 'astro-eslint-parser';
import jsxA11y from 'eslint-plugin-jsx-a11y';
import prettierConfig from 'eslint-config-prettier';

export default [
  { ignores: ['.astro/', 'dist/', 'node_modules/'] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ['**/*.astro'],
    languageOptions: {
      parser: astroParser,
      parserOptions: { parser: tseslint.parser, extraFileExtensions: ['.astro'], ecmaVersion: 'latest', sourceType: 'module' },
      globals: { URL: 'readonly', URLSearchParams: 'readonly' },
    },
    plugins: { astro: astroPlugin, 'jsx-a11y': jsxA11y },
    rules: { ...astroPlugin.configs.recommended.rules, ...jsxA11y.configs.recommended.rules },
  },
  prettierConfig,
];
```

**Key rules enforced:**
- JS/TS recommended (via `@eslint/js` + `typescript-eslint`)
- Astro recommended (via `eslint-plugin-astro`)
- a11y strict on `.astro` files (via `eslint-plugin-jsx-a11y` — alt tags, ARIA, semantic headers)
- Prettier compatibility (via `eslint-config-prettier` — disables rules that conflict)

**Glob pitfall:** The lint glob `src/**/*.{astro,ts,js}` also matches files in `src/assets/`. Ensure no stale `.ts` files exist in `src/` root (e.g., old `src/content.config.ts`). ESLint's `--print-config <file>` and `--debug` flags help diagnose config resolution issues.

### Prettier (`.prettierrc`)

```json
{
  "semi": true,
  "singleQuote": true,
  "tabWidth": 2,
  "useTabs": false,
  "printWidth": 100,
  "trailingComma": "all",
  "bracketSpacing": true,
  "arrowParens": "always",
  "endOfLine": "lf",
  "plugins": ["prettier-plugin-astro"],
  "overrides": [{ "files": "*.astro", "options": { "parser": "astro" } }]
}
```

**Requires `prettier-plugin-astro`** for `.astro` file formatting. Without it, Prettier silently skips `.astro` files.

### package.json Scripts

```json
"lint": "eslint \"src/**/*.{astro,ts,js}\"",
"format": "prettier --write \"src/**/*.{astro,ts,js,css,mdx}\""
```

### ⚠️ Pitfalls — Code Quality

- **`typescript-eslint` meta-package:** Import from `typescript-eslint`, NOT `@typescript-eslint/eslint-plugin`. The flat config wrapper is the modern approach.
- **`prettier-plugin-astro` required:** Without it, `prettier --write` silently ignores `.astro` files.
- **Browser globals in `.astro` files:** Add `URL` and `URLSearchParams` as readonly globals in the astro-specific config block, or ESLint reports them as undefined.
- **ESLint cache:** When rules seem to not apply despite correct config, clear `.astro/` cache and any `node_modules/.cache/` directories.

- **Lighthouse:** Target 100/100 across all four categories
- **Accessibility:** WCAG AA — keyboard nav, ARIA labels, contrast ratios
- **Semantic HTML:** Every page must use landmark elements; smoke test asserts their presence
- **Zero JS footprint:** Only add `client:load`/`client:visible` when explicitly interactive

## 🧱 Component Architecture: Atoms

### RetroText — Foundational Typography Atom

Location: `src/components/atoms/RetroText.astro`

A dynamic HTML element wrapper that enforces one of two font tracks via a `variant` prop:

```astro
---
interface Props {
  tag?: 'h1' | 'h2' | 'h3' | 'p' | 'span';
  variant?: 'pixel' | 'mono';
}
const { tag: Element = 'p', variant = 'mono' } = Astro.props;
---
<Element class={`retro-text variant-${variant}`}>
  <slot />
</Element>
```

- `variant="pixel"` → `var(--font-family-display)` (Syncopate 700) — headers, labels
- `variant="mono"` → `var(--font-family-body)` (Inter) — body prose, code mentorship
- Defaults: `tag="p"`, `variant="mono"`
- Scoped CSS resets `margin: 0` and sets `line-height: 1.5` for predictable composition

**Usage — homepage hero** (`src/pages/index.astro`):
```astro
<RetroText tag="h1" variant="pixel">SAY 'HELLO WORLD' AGAIN!</RetroText>
<RetroText tag="p" variant="mono">Yeah, you read that right…</RetroText>
```

### ⚠️ Pitfalls — Font Loading

- **Google Fonts payload must be in BOTH `BaseHead.astro` and `SEOHead.astro`.** The blog has two head component trees — pages using `SEOHead` would render without web fonts if only `BaseHead` loads them. Both files must carry identical `<link>` preconnect + stylesheet tags. After updating one, verify the other matches.
- **No `<Font>` component or `@fontsource/` packages.** The project migrated away from Astro's built-in `<Font>` component to direct Google Fonts `<link>` tags for zero-JS font loading. Do NOT reintroduce `<Font>` or font loader libraries.
- **Inter provides the reading experience; Syncopate is display-only.** Syncopate at 700 weight is intentionally all-caps and wide-tracked — it is NOT suitable for body text. Never apply `--font-family-display` to paragraphs or long-form content.

### ⚠️ Pitfalls — Global Stylesheet Import Consistency

- **Every `<head>` component MUST import `global.css`.** The `BaseHead.astro` component imports `../styles/global.css` and provides the `:root` CSS custom properties and global dark body styles. If any page uses a different head component (e.g., `SEOHead.astro`) that DOES NOT import `global.css`, that page will render without any CSS custom properties — all `var(--color-sys-bg)`, `var(--color-sys-text)`, etc. resolve to their initial values (transparent, black text), producing a broken light-theme appearance on a dark-theme site.
- **Symptom:** Scoped component styles look correct on disk but the browser renders `background: rgba(0,0,0,0)` (transparent) and `color: rgb(0,0,0)` (black). This looks like a CSS specificity issue but is actually a missing stylesheet import.
- **Diagnostic:** In the browser console, run `getComputedStyle(document.documentElement).getPropertyValue('--color-sys-bg')` — if it returns an empty string, `global.css` is not loaded on this page.
- **Fix:** Add `import '../styles/global.css';` to the top of any head/meta component that doesn't have it. Verify both `BaseHead.astro` and `SEOHead.astro` (and any other `<head>` component) carry this import.
- **Current head components:** `BaseHead.astro` (has import ✓), `SEOHead.astro` (must have import — if missing, add it).

### ⚠️ Pitfalls — Font Stack Migration (Scoped Override Bug)

- **Root cause:** When migrating font families (e.g., `Press Start 2P` → `Syncopate`, `JetBrains Mono` → `Fira Code`), updating `:root` custom properties in `global.css` is NOT sufficient. Every component with a scoped `<style>` block that contains a hardcoded `font-family` string (e.g., `font-family: 'Press Start 2P', monospace`) will override the global token — scoped styles win over `:root`.
- **Migration procedure:**
  1. Update `:root` custom properties in `global.css` (`--font-family-display`, `--font-family-body`, `--font-family-mono`)
  2. Update Google Fonts `<link>` URLs in **both** `BaseHead.astro` and `SEOHead.astro` (they duplicate font loading for different layout trees)
  3. **Grep all component scoped `<style>` blocks** for the old font name strings and replace with `var(--font-family-*)` tokens
  4. Verify: `grep -r "font-family" src/components/ --include="*.astro" | grep -v "var(--font-family"` must return zero results
  5. Restart the dev server (Vite HMR cache may serve old styles)
  6. Verify in browser: `getComputedStyle(element).fontFamily` on both heading and body elements
- **Known components that had hardcoded fonts (all patched):** `atoms/RetroText.astro`, `molecules/HardwareSwitch.astro`, `organisms/GlobalScoreboard.astro`, `PostAuditBanner.astro`
- **Font stack mapping:**
  | Old Font | New Font | CSS Token |
  |----------|----------|-----------|
  | `Press Start 2P` | `Syncopate` (wght 700) | `var(--font-family-display)` |
  | `Atkinson Hyperlegible` | `Inter` (wght 400/500/700) | `var(--font-family-body)` |
  | `JetBrains Mono` | `Fira Code` (wght 400/600) | `var(--font-family-mono)` |

### ⚠️ Pitfalls — Migrating Scoped Styles from Legacy Light Tokens to Dark NES

- **Legacy token patterns to search for and replace:** `rgb(var(--gray-dark))`, `rgb(var(--gray))`, `rgb(var(--black))`, `rgb(var(--accent))`, `var(--box-shadow)`, `border-radius: 12px`. These are light-theme leftovers from the Astro starter template.
- **Token migration map:**
  | Legacy Pattern | Dark NES Replacement |
  |----------------|---------------------|
  | `rgb(var(--gray-dark))` | `var(--color-sys-text)` |
  | `rgb(var(--gray))` | `var(--color-brand-primary)` |
  | `rgb(var(--black))` | `var(--color-sys-text)` |
  | `rgb(var(--accent))` | `var(--color-brand-accent)` |
  | `var(--box-shadow)` | Remove, or replace with `border` using `var(--size-border-pixel) solid var(--color-sys-surface)` |
  | `border-radius: 12px` | `border: var(--size-border-pixel) solid var(--color-sys-surface)` |
- **When migrating any page's scoped `<style>` block:** Also add `background-color: var(--color-sys-bg); color: var(--color-sys-text);` to the `main` element to ensure the dark canvas fills the page, not just the header/footer.
- **Files that needed migration (already completed):** `BlogPost.astro`, `blog/index.astro`. Check these if they regress.

### ⚠️ Pitfalls — Header & Navigation Dark Theme

- **Header must NEVER use light-theme defaults.** The starter Astro template ships with `background: white; box-shadow: ...; color: var(--black)` in `Header.astro`. This must be fully replaced with NES dark tokens.
- **Header token mapping (with native CSS Nesting):**
  ```css
  header {
    background-color: var(--color-sys-bg);
    color: var(--color-sys-text);
    border-bottom: var(--size-border-pixel) solid var(--color-sys-surface);
    padding: calc(var(--size-border-pixel) * 6) calc(var(--size-border-pixel) * 10);

    & nav { display: flex; justify-content: space-between; align-items: center; }
    & a {
      color: var(--color-brand-primary);
      font-family: var(--font-family-display);
      font-size: 0.85rem;
      text-decoration: none;
      &:hover { color: var(--color-brand-accent); }
    }
  }
  ```
- **HeaderLink.astro active state:** Use `text-decoration-color: var(--color-brand-danger)` (Konami Red) for the active nav indicator.
- **When migrating any component from light to dark:** Search for `background: white`, `background: #fff`, `box-shadow`, and `var(--black)` — these are light-theme leftovers that must be replaced with `--color-sys-*` tokens.

### ⚠️ Pitfalls — Components

- **`my-blog` has no `format` script:** The `my-blog` repo's `package.json` does not include a `format` script. Do NOT attempt `npm run format` — it will fail with "Missing script". Use `npm run build` to verify correctness instead. (Note: `my-blog` is deprecated — prefer `blog` for all new work.)
- **Dynamic element syntax:** Astro requires `tag: Element` (capitalized) in destructuring to render a dynamic HTML tag. Lowercase `tag` will not work as an element name.
- **⚠️ Do NOT name interfaces `Props` in `.astro` files:** Astro uses `Props` as a built-in global generic type. Declaring `interface Props { ... }` in frontmatter shadow it, causing ESLint errors like `'Props' is defined but never used` and `'title' is not defined on type 'Props'`. **Always use a descriptive name:**
  ```ts
  interface PageProps {
    title?: string;
    description?: string;
  }
  const { title = 'Default', description = 'Default desc' } = Astro.props as PageProps;
  ```
- **Atomic design directory structure:** Components are organized by atomic design tier:
  - `src/components/atoms/` — foundational UI primitives (e.g., `RetroText.astro`)
  - `src/components/molecules/` — composed interactive widgets (e.g., `HardwareDashboard.astro`)
  - `src/components/organisms/` — complex composed sections (e.g., `GlobalScoreboard.astro`)
  - `src/components/` — standalone global components not in atomic tiers (e.g., `ThemeToggle.astro`, `BaseHead.astro`, `Header.astro`, `Footer.astro`, `FormattedDate.astro`, `SEOHead.astro`, `PostAuditBanner.astro`)
  - `src/layouts/` — page-level HTML wrappers (e.g., `BaseLayout.astro`)
  - Flat `src/components/` still holds legacy components (BaseHead, Header, Footer, FormattedDate, SEOHead, PostAuditBanner) used by blog pages.
- **Fallow `--yes` is DESTRUCTIVE and unreliable for Astro codebases.** `npx fallow fix --yes` incorrectly flags live exports (e.g., `SOCIAL_LINKS`, `SITE_URL`) as dead because it cannot trace Astro template bindings (`.astro` files). It may also miss actual dead code. **NEVER run `fallow fix --yes` without manual verification first.** Always use `fallow fix --dry-run` as a preview, then verify each flagged export against actual imports with `search_files`. Manual surgical cleanup (search → verify → patch/delete) is the only safe approach.
- **`fallow dead-code` false positives for imported components:** Tools report `.astro` files as "unused" because they don't trace Astro's file-based routing or `.astro` imports. If a component is imported in any `.astro` file, it is reachable. Ignore fallow dead-code warnings for components confirmed imported.
- **Vite version pinning via `overrides`:** When Astro has compatibility issues with the latest Vite, pin Vite via `overrides` in `package.json`:
  ```json
  "overrides": {
    "vite": "^7.0.0"
  }
  ```
  This forces npm to resolve Vite to the specified range regardless of what Astro's peer dependency declares. Verify with `node_modules/vite/package.json` after install.
- **Native CSS Nesting (`&`) is supported in Astro scoped `<style>` blocks.** Use it for `&:hover`, `& a`, `& nav` etc. Do NOT nest more than 2 levels deep. This replaces SCSS-style nesting within component scopes — no preprocessor needed for intra-component structure. See the "Native CSS Nesting" section above for conventions.
- **⚠️ Scoped `<style>` blocks with hardcoded `font-family` strings override `:root` CSS custom property tokens.** This is the #1 source of "wrong font rendering" bugs. Scoped styles in `.astro` files have higher specificity than global `:root` declarations, so a raw `font-family: 'Press Start 2P', monospace` in a component `<style>` wins over `font-family: var(--font-family-display)` set globally. **Rule:** EVERY `font-family` in EVERY component `<style>` block MUST use a `var(--font-family-*)` token — never a raw font name string. After any font migration, grep for leftover hardcodes: `grep -r "font-family" src/components/ --include="*.astro" | grep -v "var(--font-family"` — zero results is the only acceptable outcome.

## 🔎 JSON-LD Structured Data (SchemaGraph)

### Component

`src/components/SEO/SchemaGraph.astro` — renders a single `<script type="application/ld+json">` in `<head>` using `set:html={JSON.stringify(graphData)}`. No third-party SEO packages.

### Graph Nodes

| Node | Condition | @id |
|------|-----------|-----|
| `Person` | Always | `{siteRoot}/#person` |
| `WebSite` | Always | `{siteRoot}/#website` |
| `WebPage` | Always | `{absoluteUrl}#webpage` |
| `BlogPosting` | Only when `pubDate` prop provided | `{absoluteUrl}#blogpost` |

### Mounting Pattern

SchemaGraph must be mounted in **every layout that renders a `<head>`**, not just one. The blog has two independent layout trees:

- **`BaseLayout.astro`** — homepage and top-level pages
- **`BlogPost.astro`** — blog articles + about page

Both must import and mount SchemaGraph in `<head>`:

```astro
---
import SchemaGraph from '../components/SEO/SchemaGraph.astro';
// ... other props destructured
const canonicalUrl = new URL(Astro.url.pathname, Astro.site || 'https://ericcarlisle.com');
---
<head>
  <!-- ... other head content ... -->
  <SchemaGraph title={title} description={description} canonicalUrl={canonicalUrl} pubDate={pubDate} tags={tags} />
</head>
```

### ⚠️ Pitfalls — JSON-LD / SchemaGraph

- **"Mount once in one layout" is WRONG.** If a site has multiple layout trees (BaseLayout vs BlogPost), each must independently mount SchemaGraph. Missing a layout means those pages get zero structured data — Google Rich Results won't find BlogPosting nodes on blog articles.
- **`Astro.site` defaults to `example.com` in dev.** JSON-LD URLs will show `example.com` until `site` is set in `astro.config.mjs` for production. Verify with `JSON.parse(document.querySelector('script[type="application/ld+json"]').textContent)` in DevTools.
- **Domain consolidation is a two-file operation.** When changing the site domain (e.g., `example.com` → `ericcarlisle.com`), BOTH `astro.config.mjs` (`site:` key) AND `src/consts.ts` (`SITE_URL` export) must be updated. `Astro.site` derives from `astro.config.mjs`, but `SEOHead.astro` and other components may read `SITE_URL` from `consts.ts`. A mismatch causes `og:url` and canonical URLs to contradict each other — Google flags this as a duplicate content signal.
- **No `schema-dts` or `@unhead/schema` packages.** Pure `JSON.stringify()` via Astro's `set:html` directive. Keep it zero-dependency.
- **`keywords` from `tags` prop:** Pass `tags` as an array of strings; SchemaGraph joins them for `BlogPosting.keywords`. If no tags, the field is omitted from the node.

Full reference: `references/json-ld-schema-graph.md`

## 📰 Content Collection Pipeline

The `index.astro` homepage pulls blog posts dynamically via Astro's native `getCollection` API, replacing static bio text with a live timeline feed.

### Pattern: Timeline Feed (`src/pages/index.astro`)

```astro
---
import { getCollection } from 'astro:content';

// Fetch and sort posts by publication date descending
const allPosts = await getCollection('blog');
const sortedPosts = allPosts.sort((a, b) => b.data.pubDate.valueOf() - a.data.pubDate.valueOf());
---

<section class="timeline-feed">
  <RetroText tag="h3" variant="pixel" class="feed-title">-- LOGGED TRANSMISSIONS --</RetroText>

  {sortedPosts.length === 0 ? (
    <div class="empty-state">
      <RetroText tag="p" variant="mono">[ NO TRANSMISSIONS RECORDED IN DATA MATRIX ]</RetroText>
    </div>
  ) : (
    <div class="posts-grid">
      {sortedPosts.map((post) => (
        <article class="post-card">
          <div class="post-meta">
            <span class="post-date">
              {post.data.pubDate.toLocaleDateString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric',
              })}
            </span>
          </div>
          <a href={`/blog/${post.id}/`} class="post-link">
            <RetroText tag="h4" variant="pixel">{post.data.title}</RetroText>
          </a>
          <RetroText tag="p" variant="mono" class="post-desc">{post.data.description}</RetroText>
        </article>
      ))}
    </div>
  )}
</section>
```

### Feed CSS Pattern (scoped in `index.astro`)

```css
.timeline-feed { display: flex; flex-direction: column; gap: calc(var(--size-border-pixel) * 6); }
.posts-grid { display: flex; flex-direction: column; gap: calc(var(--size-border-pixel) * 8); }
.post-card {
  border-left: var(--size-border-pixel) solid var(--color-sys-surface);
  padding-left: calc(var(--size-border-pixel) * 6);
  transition: border-color 0.1s steps(2);  /* Crunchy 2-frame arcade flicker */
  &:hover { border-color: var(--color-brand-accent); }  /* Native CSS Nesting */
}
.post-link { text-decoration: none; color: var(--color-sys-text);
  &:hover h4 { color: var(--color-brand-accent); }  /* Native CSS Nesting */
}
```

### ⚠️ Pitfalls — Content Collection Pipeline

- **Always sort explicitly.** `getCollection` returns records in filesystem order — never assume chronological ordering. Use `.sort((a, b) => b.data.pubDate.valueOf() - a.data.pubDate.valueOf())` for newest-first.
- **Handle the empty state.** A fresh repo may have no posts yet. Render a styled placeholder rather than an empty section.
- **Use `post.id` (not `post.slug`) for link paths.** In Astro 6 content collections with `glob` loaders, the `slug` property is `undefined` — access it via `post.id` instead. Links follow `/blog/${post.id}/`. Using `post.slug` silently produces `/blog/undefined/` URLs that resolve to 404s.
- **`transition: steps(2)` for arcade hover.** The CSS `steps()` timing function creates a hard 2-frame flicker on hover — zero JS, pure CSS retro feel. Only works on animatable properties like `border-color`.

## 🎨 Native CSS Nesting in Astro Scoped Styles

Astro's `<style>` blocks support native CSS Nesting (`&` selector) in all modern browsers. This eliminates the need for BEM, SCSS nesting, or repeated parent selectors within a single component's scoped block.

**Convention:** Use `&` nesting for pseudo-classes (`&:hover`), child elements (`& a`, `& nav`), and media queries inside the scoped block. Do NOT nest more than 2 levels deep — KISS.

```css
/* ✅ Good — flat, readable nesting */
header {
  background-color: var(--color-sys-bg);
  & nav { display: flex; justify-content: space-between; }
  & a { color: var(--color-brand-primary);
    &:hover { color: var(--color-brand-accent); }
  }
}

/* ❌ Bad — deep nesting hurts readability */
header { & nav { & ul { & li { & a { &:hover { ... } } } } } }
```

## 🔍 Fallow Code Quality Auditing

### Running Fallow

```bash
# Full combined analysis (dead-code + dupes + health) — use --no-cache for fresh read
npx fallow --no-cache

# Health-only (complexity, maintainability, hotspots)
npx fallow health --no-cache
```

**Exit code 1 is normal** when fallow finds issues — it still prints the full report. Do not treat exit 1 as a fatal CI failure for the known false positives below.

### Interpreting Fallow Results

- **Health score** (letter grade A–F): composite of MI, dead code %, and unused deps. Target: A or B.
- **`lighthouserc.js` as "dead file"**: False positive — fallow doesn't recognize run-time config files. Ignore.
- **`@unlighthouse/cli` as "unused dependency"**: False positive — it's invoked via npm scripts (`"audit"`), which fallow cannot trace. Ignore.
- **Test-only production dependencies** (`@astrojs/mdx`, `@astrojs/sitemap`): Astro integration packages that live in `dependencies` but are only used at build time. Move to devDeps if strict fallow compliance is needed, but Astro convention places them in `dependencies`.

### ⚠️ Pitfalls — Dependency Hygiene (from Fallow findings)

- **`sharp` belongs in `devDependencies`, not `dependencies`.** It's an image optimization tool used only at build time by Astro. Placing it in `dependencies` inflates production installs and triggers fallow warnings.
- **`@eslint/js` must be explicitly in `devDependencies`.** The ESLint flat config imports it (`import js from '@eslint/js'`), but it's not auto-installed by `eslint` or `typescript-eslint`. Missing it causes `"@eslint/js" is not found` at lint time.
- **Remove `@typescript-eslint/eslint-plugin` and `@typescript-eslint/parser` when using `typescript-eslint` umbrella.** The `typescript-eslint` meta-package re-exports both. Having the individual packages in `devDependencies` is redundant and creates version skew risk. Delete them from `package.json` and reinstall.
- **After any `package.json` dependency changes:** Always run `NODE_ENV=development npm install` to sync `node_modules`, then re-run `npx fallow --no-cache` to confirm the fix.

## 🗂️ Information Architecture

| Route | Purpose |
|-------|---------|
| `index.astro` | Splash page, post timeline |
| `/about` | Resume, stack overview |
| `/portfolio` | Project showcase |
| `/tags/` & `/categories/` | Content taxonomies |

## 📐 Layout Pattern

Every page follows this structure:

```astro
---
// global.scss tokens are available project-wide
---
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>8-Bit Blog</title>
  </head>
  <body>
    <header><nav aria-label="Primary navigation">…</nav></header>
    <main>…</main>
    <footer>…</footer>
  </body>
</html>
```

## 🧪 Testing

Playwright smoke test assertions:
1. Page compiles (HTTP 200)
2. Hero heading renders
3. Semantic landmarks present (header, main, footer, nav)
4. `aria-labelledby` links section to heading
5. `<html lang="en">` set

Run: `npx playwright test`
